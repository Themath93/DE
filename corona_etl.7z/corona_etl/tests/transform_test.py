import unittest
from datajob.etl.transform.corona_patient import CoronaPatientTransformer

class MTest(unittest.TestCase):

    def test1(self):
        CoronaPatientTransformer.transform()

if __name__ == "__main__":
    unittest.main()